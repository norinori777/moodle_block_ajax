<?php

class studygroup_entries
{
    private $entries;

    public function __construct($entries){
        $this->entries = $entries;
    }
}