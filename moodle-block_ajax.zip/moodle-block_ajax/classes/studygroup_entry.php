<?php

class studygroup_entry
{
    public function __construct(){

    }
    
    
}