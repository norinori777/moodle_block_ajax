<?php

$json_string = file_get_contents('php://input');
$obj = json_decode($json_string);

if($data != null){
    echo json_encode(array('result' => 'OK'));
}
echo json_encode(array('result' => 'NG'));